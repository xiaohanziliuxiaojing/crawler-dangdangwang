# coding: utf-8
import requests
from bs4 import BeautifulSoup
import json
import os

header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36',
    'Connection': 'keep-alive'
}

url = "http://product.dangdang.com/index.php?r=callback%2Fdetail&productId=24105846&templateType=publish&describeMap=0100003041%3A1&shopId=0&categoryPath=01.41.70.02.03.00"


def makedirs(path):  
		folder = os.path.exists(path)#判断路径下文件夹是否存在
		if not folder:
			os.makedirs(path)#mkdir 和 makedirs
			print ("picture文件夹创建成功") 
		else:  
			print ("picture文件夹已经存在") 


def get_img(url,header):#抓取详情页图片
	web_data = requests.get(url, headers=header)
	#print(web_data.encoding)
	web_data.encoding = 'UTF-8'
	#print(web_data.encoding)
	#print(web_data.content)
	data = json.loads(web_data.content)#Json格式字符串解码，转换成Python对象;json.dumps()把一个Python对象编，码转换成Json字符串。
	#print(data)
	# print(data['data']['html'])
	soup = BeautifulSoup(data['data']['html'], 'lxml')
	img = soup.find('div',class_="descrip")
	img_url = img.find('img')['src']
	#print(img_url)
	imgjpg = img_url.split('/')[-1]
	try:
		urllib.request.urlretrieve(img_url,'{}/{}'.format(img_path,img_url.split('/')[-1]))#url,路径
		print('正在打印图片'+ imgjpg)
	except Exception as e:
		print (e)


kuang = []
def get_content(url,header):#抓取详情页的内容
	web_data = requests.get(url, headers=header)
	web_data.encoding = 'UTF-8'
	data = json.loads(web_data.content)#Json格式字符串解码，转换成Python对象;json.dumps()把一个Python对象编，码转换成Json字符串。
	#print(data)
	soup = BeautifulSoup(data['data']['html'], 'lxml')

	div = soup.find('div', id="abstract")#拿到编辑推荐
	ds = soup.find('div', class_="title")#拿到标题
	kuang.append(ds.text)
	ps = div.find_all('p')
	for p in ps:
	    kuang.append("".join(p.text.split()))# join() 方法用于将序列中的元素以指定的字符连接生成一个新的字符串。

	div1 = soup.find('div', id="content")#拿到内容简介
	ds1 = div1.find('div', class_="title")#拿到标题
	kuang.append(ds1.text)
	ps1 = div1.find_all('p')
	for p in ps1:
	    kuang.append("".join(p.text.split()))

	div2 = soup.find('div', id="authorIntroduction")#拿到作者简介
	ds2 = div2.find('div', class_="title")#拿到标题
	kuang.append(ds2.text)
	ps3 = div2.find_all('p')
	for p in ps3:
	    kuang.append("".join(p.text.split()))


def save():#txt存储文字
	try:
		os.getcwd()
		os.chdir(file)
		with open('save''.txt','w') as fo:
			fo.write('\n'.join(kuang))
			fo.close()
	except Exception as err:
		fillte='导出失败:'+str(err)
		print(fillte)
	else:
		succefull='导出成功'
		print(succefull)


img_path='f:/ddm'
file = 'f:/ddm/save'

def main():
	makedirs(img_path)
	makedirs(file)
	get_img(url,header)
	get_content(url,header)
	save()


if __name__ == "__main__":
	main()
